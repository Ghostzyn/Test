# Desktop Drawers

Aplicación nativa C# / WPF para Windows 11 x64, sin navegador ni dependencias de terceros. Usa .NET 10 LTS. El repositorio incluye la solución, la aplicación, una biblioteca independiente de WPF y pruebas ejecutables sin paquetes de pruebas externos.

## Compilar y ejecutar en Windows

Instala el SDK .NET **10.0.403** x64 (Visual Studio es opcional). Desde la raíz del repositorio:

```powershell
dotnet restore DesktopDrawers.sln
dotnet build DesktopDrawers.sln -c Release
dotnet run --project tests/DesktopDrawers.Tests -c Release
dotnet run --project src/DesktopDrawers -c Release
```

El proyecto de pruebas es un runner de consola: `dotnet run` ejecuta las pruebas y devuelve código distinto de cero si hay fallos. `dotnet test` no ejecuta este runner.

Publicación autónoma, sin necesitar .NET instalado en el equipo de destino:

```powershell
dotnet publish src/DesktopDrawers/DesktopDrawers.csproj -c Release -r win-x64 --self-contained true -o artifacts/win-x64 -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true
```

Ejecuta `artifacts/win-x64/DesktopDrawers.exe`. Es una aplicación portátil sin instalador, sin firma Authenticode; Windows puede mostrar su advertencia habitual. El archivo único extrae bibliotecas nativas en la carpeta temporal administrada por .NET. No requiere permisos de administrador para el uso habitual.

## Uso

1. Abre el administrador y pulsa **Nuevo cajón**. Puedes crear varios.
2. Arrastra la barra superior para mover el cajón; usa sus bordes para redimensionarlo. La flecha contrae o expande conservando el tamaño expandido.
3. El engranaje permite cambiar nombre, fondo HEX, título HEX y opacidad del fondo (10–100 %). Los textos e iconos conservan su opacidad. Para RGB, convierte cada componente a su par HEX; todavía no hay selector RGB gráfico.
4. Arrastra un `.lnk` o `.url` que esté directamente en el escritorio del usuario o público hacia el cajón. El archivo se copia de forma durable a AppData y después se retira del escritorio. No se mueve el ejecutable al que apunta.
5. Doble clic abre el acceso mediante el shell de Windows. Solo deben importarse accesos de confianza: ejecutarlos tiene el mismo efecto que abrirlos desde Explorer.
6. Arrastra un elemento de un cajón a otro para reorganizarlo. El menú contextual permite abrirlo o **restaurarlo al escritorio**, quitándolo del cajón sin borrarlo permanentemente.
7. **Restaurar todo** devuelve los accesos antes de dejar de usar la aplicación. Eliminar un cajón requiere confirmación y restaura sus accesos primero; un error detiene la eliminación.
8. Ctrl+Alt+D y el botón del administrador alternan la visibilidad global. Si el atajo está ocupado se informa al iniciar y sigue disponible el botón.
9. **Guardar y salir**, o cerrar el administrador, termina la aplicación. No hay proceso residente en la bandeja.

## Datos y recuperación

Datos en `%LOCALAPPDATA%\DesktopDrawers`:

- `state.json`: cajones, geometría, colores, estado global y rutas de los accesos.
- `state.json.bak`: versión anterior del estado; se usa si la principal es ilegible. Si ambas son ilegibles, el inicio falla visiblemente y no las reemplaza por un estado vacío.
- `Shortcuts`: accesos con nombres GUID que evitan colisiones. No borres esta carpeta al quitar los binarios de la aplicación.

El JSON se escribe en un temporal, se fuerza a disco y se sustituye mediante `File.Replace`. El registro del acceso se guarda antes de retirar el original. Un fallo puede dejar una copia duplicada, priorizando conservar los archivos. Si una operación informa un error, revisa la entrada y usa Restaurar; no repitas manualmente borrados. La restauración elige un nombre libre (`Nombre (1).lnk`, etc.) sin sobrescribir el archivo existente. Guarda la nueva ruta antes de borrar la copia administrada. Si faltan todas las copias, conserva el registro y muestra un error.

Se consulta `Environment.SpecialFolder.DesktopDirectory` y `CommonDesktopDirectory`, respetando ubicaciones redirigidas. La versión inicial rechaza archivos marcados Offline o ReparsePoint para evitar mover placeholders de OneDrive o enlaces del sistema: materializa una copia local antes de importarlos. Solo acepta accesos directamente en esos escritorios, no en subcarpetas. Los accesos públicos protegidos pueden dar error de permisos; no se elevan privilegios. Si el escritorio original no existe, se intenta un escritorio disponible. No se sincronizan cambios externos al JSON durante la ejecución. Una exclusión mutua evita dos instancias por usuario.

Ante un corte de energía, realiza copia de seguridad de toda la carpeta de datos antes de intervenir. Los restos `.pending` corresponden a copias interrumpidas; el original no se retira hasta finalizar la copia. Esta estrategia no sustituye una copia de seguridad del disco.

## Integración con Explorer: alternativa conservadora

Esta versión **no reparenta ventanas en WorkerW/Progman ni modifica Explorer**. Esas jerarquías (incluido `SHELLDLL_DefView`) son detalles internos, cambian entre versiones y requieren pruebas en Windows real, incluyendo reinicios de Explorer, DPI y monitores múltiples. El reparentado también puede destruir o desconectar ventanas cuando Explorer se reinicia.

La alternativa implementada utiliza `SetWinEventHook(EVENT_SYSTEM_FOREGROUND, WINEVENT_OUTOFCONTEXT)` y `RegisterHotKey`; no inyecta código ni instala hooks de ratón. Los cajones no son Topmost, no ocupan la barra de tareas y se ocultan cuando una aplicación ajena pasa al primer plano, incluidos los juegos. Se vuelven a mostrar cuando el primer plano es Progman/WorkerW o la propia aplicación y la visibilidad global está activada. Por ello se ocultan también cuando otra aplicación no maximizada está activa: no son elementos nativos embebidos en el escritorio. No dependen de un handle persistente de Explorer; la siguiente notificación de primer plano vuelve a evaluar su clase tras un reinicio.

El doble clic sobre una zona vacía del escritorio **no está implementado**: distinguir de forma fiable los iconos de Explorer sin inyección ni hooks globales requiere validación adicional. Ctrl+Alt+D es la alternativa segura solicitada. No se atribuye a esta implementación equivalencia completa con iTop Easy Desktop.

## Arquitectura

- `DesktopDrawers.Core/Models`: estado independiente de UI.
- `DesktopDrawers.Core/Persistence`: JSON, validación básica y recuperación.
- `DesktopDrawers.Core/Services`: operaciones de archivos y restauración.
- `DesktopDrawers/Views`: ventanas WPF y controles.
- `DesktopDrawers/ViewModels`: representación de accesos e iconos.
- `DesktopDrawers/Services`: coordinación, guardado diferido y extracción de iconos.
- `DesktopDrawers/NativeInterop`: eventos de primer plano y atajo.

El guardado de geometría se difiere 400 ms para agrupar cambios; no existe sondeo periódico del escritorio. Los handles de icono se liberan mediante `DestroyIcon`, los bitmaps se congelan y el hook se libera al salir. Actualmente los iconos se cargan al refrescar el cajón: la carga diferida y virtualización de grandes colecciones quedan pendientes. No hay mediciones de consumo ni afirmaciones numéricas de rendimiento.

## Validación y estado de las fases

En este entorno Linux se verificó compilación WPF cruzada y se ejecutaron las pruebas del núcleo. **WPF y las API de Windows no pueden ejecutarse aquí**; una compilación correcta no valida la interfaz ni la integración. La publicación Windows se genera mediante cross-compilation; debe probarse en Windows 11 antes de usar accesos importantes.

- Fase 1: código implementado para ventanas, geometría, nombre, expansión, HEX/opacidad y persistencia; comprobación gráfica pendiente. Sin animación, por simplicidad.
- Fase 2: código implementado para importar, iconos del shell, abrir, mover y restaurar. Lógica de archivos probada con fixtures; accesos reales e iconos pendientes de Windows.
- Fase 3: alternativa de visibilidad y atajo implementada; integración nativa WorkerW y doble clic del escritorio pendientes. Sin pruebas de Explorer en esta máquina.
- Fase 4: pruebas del núcleo, compilación y publicación; quedan las pruebas manuales Windows, perfiles de rendimiento, firma e instalador.

### Comprobaciones manuales obligatorias en Windows 11

Usa primero accesos descartables y una copia de seguridad:

- Crear varios cajones, mover y redimensionar; contraer, reiniciar y comprobar geometría, colores y visibilidad.
- Probar HEX inválido, opacidad mínima y escalados DPI 100/150/200 %, cambio/desconexión de monitores.
- Importar un `.lnk` y un `.url` reales; comprobar iconos y apertura, traslado entre cajones y restauración con nombres duplicados.
- Probar escritorio público sin permisos, OneDrive local y placeholder, ruta inexistente y error de guardado.
- Restaurar todo, eliminar un cajón y cancelar su confirmación; verificar conservación de los archivos.
- Activar otras aplicaciones y un juego a pantalla completa; probar Alt+Tab, barra de tareas, Win+D, Ctrl+Alt+D y conflicto del atajo.
- Reiniciar Explorer, volver al escritorio y comprobar reaparición e interacción. Si la clase del escritorio cambia, usar el administrador y registrar la versión de Windows antes de ajustar la detección.
- Cerrar y abrir, intentar segunda instancia y probar recuperación de JSON dañado con copia previa de los datos.

## Entorno cloud

Linux permite desarrollar, compilar y probar el núcleo; no puede alojar la interfaz WPF. No hay servicios web ni URL de previsualización.

```bash
bash scripts/setup-cloud.sh
source scripts/activate-cloud.sh
```

El script instala el SDK fijado desde Microsoft con comprobación SHA-512 si falta, conserva TLS, usa caches dentro de `/workspace`, restaura dependencias, compila y ejecuta las pruebas. Cada tarea ya tiene un checkout aislado: usar el existente, sin crear worktrees salvo petición explícita.
